# StormFN-Backend
StormFN Current Backend by notpies and doener

sorry but if you think this backend is skidded because it has the same file names then you need some knowledge, its about the code and not the file names. 
